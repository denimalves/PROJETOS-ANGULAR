package br.com.apicadcli.apicliente.controle;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.apicadcli.apicliente.modelo.produto;
import br.com.apicadcli.apicliente.repositorio.RepositorioProduto;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;



@RestController
@CrossOrigin 
public class controleProduto {

    @Autowired
    private RepositorioProduto acao;

    @GetMapping("/produtos")
    public Iterable<produto> selecionar() {
        return acao.findAll();
    }
    
    @PostMapping("/produtos")
    public produto cadastrar(@RequestBody produto p) {
        return acao.save(p);
    }
    
    @GetMapping("/produtos/{id}")
    public Optional<produto> selecionarporcodigo(@PathVariable long id) {
        return acao.findById(id);
    }

    @PutMapping("/produtos/{id}")
    public produto editar(@PathVariable long id, @RequestBody produto p) {
        return acao.save(p);
    }

    @DeleteMapping("/produtos/{id}")
    public void remover(@PathVariable long id) {
    acao.deleteById(id);
    }
}
