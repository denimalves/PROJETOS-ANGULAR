package br.com.apicadcli.apicliente.repositorio;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import br.com.apicadcli.apicliente.modelo.produto;

@Repository
public interface RepositorioProduto extends CrudRepository<produto, Long>{

    
}