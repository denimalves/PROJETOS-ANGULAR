package br.com.apicadcli.apicliente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiclienteApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiclienteApplication.class, args);
	}

}
