package br.com.apicadcli.apicliente.modelo;

public class venda {

}
