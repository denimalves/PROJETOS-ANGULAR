import {
  ArrayDataSource,
  DataSource,
  SelectionModel,
  UniqueSelectionDispatcher,
  _DisposeViewRepeaterStrategy,
  _RecycleViewRepeaterStrategy,
  _VIEW_REPEATER_STRATEGY,
  _ViewRepeaterOperation,
  getMultipleValuesInSingleSelectionError,
  isDataSource
} from "./chunk-FEQAJRIR.js";
import "./chunk-SAS3ZIMR.js";
import "./chunk-4N4GOYJH.js";
import "./chunk-5OPE3T2R.js";
import "./chunk-FHTVLBLO.js";
import "./chunk-WDMUDEB6.js";
export {
  ArrayDataSource,
  DataSource,
  SelectionModel,
  UniqueSelectionDispatcher,
  _DisposeViewRepeaterStrategy,
  _RecycleViewRepeaterStrategy,
  _VIEW_REPEATER_STRATEGY,
  _ViewRepeaterOperation,
  getMultipleValuesInSingleSelectionError,
  isDataSource
};
//# sourceMappingURL=@angular_cdk_collections.js.map
