import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  ArrayDataSource,
  DataSource,
  SelectionModel,
  UniqueSelectionDispatcher,
  _DisposeViewRepeaterStrategy,
  _RecycleViewRepeaterStrategy,
  _VIEW_REPEATER_STRATEGY,
  _ViewRepeaterOperation,
  getMultipleValuesInSingleSelectionError,
  isDataSource
} from "./chunk-IU2GEVOX.js";
import "./chunk-PFSBF4ML.js";
import "./chunk-TDK5NIWS.js";
import "./chunk-WBQSER3X.js";
import "./chunk-RK6XMIZN.js";
import "./chunk-YHCV7DAQ.js";
export {
  ArrayDataSource,
  DataSource,
  SelectionModel,
  UniqueSelectionDispatcher,
  _DisposeViewRepeaterStrategy,
  _RecycleViewRepeaterStrategy,
  _VIEW_REPEATER_STRATEGY,
  _ViewRepeaterOperation,
  getMultipleValuesInSingleSelectionError,
  isDataSource
};
//# sourceMappingURL=@angular_cdk_collections.js.map
