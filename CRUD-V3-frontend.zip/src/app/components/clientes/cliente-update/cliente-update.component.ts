import { ClienteService } from './../../../cadastro/clientes/cliente.service';
import { cliente } from './../../../cadastro/clientes/cliente.modelo';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';



@Component({
  selector: 'app-cliente-update',
  standalone: false,
  
  templateUrl: './cliente-update.component.html',
  styleUrl: './cliente-update.component.css'
})



export class ClienteUpdateComponent implements OnInit{

  clientes:cliente;

  constructor (private router: Router,
              private servico: ClienteService,
              private route: ActivatedRoute

  ) {  }

ngOnInit(): void {
    const codigo = +this.route.snapshot.paramMap.get('codigo');
    this.servico.lerporcodigo(codigo).subscribe(cliente => {
      this.clientes = cliente;
    })
}


  atualizar() : void {
   this.servico.atualizar(this.clientes).subscribe(() => {

      this.servico.showMessage("Cliente atualizado com sucesso");
      this.router.navigate(["/clientes"]);
    })
    console.log(this.clientes);
  }

  cancelar() : void{
    this.router.navigate(["/clientes"]);
  }

}
