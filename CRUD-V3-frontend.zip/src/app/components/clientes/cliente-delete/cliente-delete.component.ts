import { url } from 'node:inspector';
import { Component, OnInit } from '@angular/core';
import { cliente } from '../../../cadastro/clientes/cliente.modelo';
import { ClienteService } from '../../../cadastro/clientes/cliente.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-cliente-delete',
  standalone: false,
  
  templateUrl: './cliente-delete.component.html',
  styleUrl: './cliente-delete.component.css'
})
export class ClienteDeleteComponent implements OnInit {

  clientes:cliente;

constructor  (private router: Router,
              private servico: ClienteService,
              private route: ActivatedRoute

  ) {  }

ngOnInit(): void {
    const codigo = +this.route.snapshot.paramMap.get('codigo');
    this.servico.lerporcodigo(codigo).subscribe(cliente => {
      this.clientes = cliente;
    })
}


  cancelar() {
    this.router.navigate(["/clientes"]);
}
remover() {
  this.servico.remover(this.clientes.codigo).subscribe(() => {
    this.servico.showMessage('Cliente excluido com sucesso')
    this.router.navigate(['/clientes']);
  })
}

}
