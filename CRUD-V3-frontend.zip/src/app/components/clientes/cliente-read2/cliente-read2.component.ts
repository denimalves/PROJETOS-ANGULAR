import { ClienteService } from './../../../cadastro/clientes/cliente.service';
import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { MatTable } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { ClienteRead2DataSource } from './cliente-read2-datasource';
import { cliente } from '../../../cadastro/clientes/cliente.modelo';

@Component({
  selector: 'app-cliente-read2',
  standalone: false,
  templateUrl: './cliente-read2.component.html',
  styleUrl: './cliente-read2.component.css'
})
export class ClienteRead2Component implements AfterViewInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatTable) table!: MatTable<cliente>;
  dataSource = new ClienteRead2DataSource();

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['codigo', 'nome', 'cep', 'endereco', 'numero', 'bairro',
                      'cidade', 'estado', 'cpf', 'datadenascimento', 'datadecadastro', 'acoes'];
  cliente: cliente[];

    constructor(private clienteService: ClienteService) {}

    ngOnInit(): void {
      this.clienteService.selecionartodos().subscribe(cliente => {
        this.cliente = cliente;
      })
    }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.table.dataSource = this.dataSource;
  }


}
