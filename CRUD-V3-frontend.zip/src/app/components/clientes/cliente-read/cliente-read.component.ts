import { Component } from '@angular/core';

@Component({
  selector: 'app-cliente-read',
  standalone: false,
  
  templateUrl: './cliente-read.component.html',
  styleUrl: './cliente-read.component.css'
})
export class ClienteReadComponent {

}
