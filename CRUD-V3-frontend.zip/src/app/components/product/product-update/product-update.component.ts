import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from './../../../componente/product/product.service';
import { Component, model, OnInit, NgModule } from '@angular/core';
import { Product } from './../../../componente/product/product.model';
import { identity } from 'rxjs';
import { get } from 'http';

@Component({
  selector: 'app-product-update',
  standalone: false,
  
  templateUrl: './product-update.component.html',
  styleUrl: './product-update.component.css'
})
export class ProductUpdateComponent implements OnInit{

  product: Product

  constructor( 
    private productService: ProductService,
    private router: Router,
  private route: ActivatedRoute
) { }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id')
    this.productService.readById(id).subscribe(product => {
      this.product = product
    });
  }

  updateProduct(): void {
    this.productService.update(this.product).subscribe(() => {
      this.productService.showMessage('Produto Atualizado com Sucesso')
      this.router.navigate(['/products']);
    })
  }

  cancel(): void {
    this.router.navigate(['/products'])
  }
}
