import { ProductService } from './../../../componente/product/product.service';
import { Product } from './../../../componente/product/product.model';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-read',
  standalone: false,
  
  templateUrl: './product-read.component.html',
  styleUrl: './product-read.component.css'
})
export class ProductReadComponent implements OnInit {
  
  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['id', 'nome', 'preco', 'action'];
  products : Product[];

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.productService.read().subscribe(products => {
      this.products = products
      console.log(products)
    })
  }
}

