import { cliente } from './cliente.modelo';
import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../components/template/header/header.service';
import { Router } from '@angular/router';
import { ClienteService } from './cliente.service';

@Component({
  selector: 'app-clientes',
  standalone: false,
  
  templateUrl: './clientes.component.html',
  styleUrl: './clientes.component.css'
})
export class ClientesComponent implements OnInit{



  //Json de Clientes

  clientes:cliente[] = [] ;


    constructor(private router: Router,
                private headerService: HeaderService,
                private clienteServico:ClienteService) {
          
                  headerService.headerData = {
                  title: 'Clientes',
                  icon: 'person',
                  routerUrl: '/clientes'
          }
    }

    //metodo para selecionar todos clientes

    selecionartodos() : void {
      this.clienteServico.selecionartodos().subscribe(retorno => this.clientes = retorno);
      }
   
      //metodo para rotear para criar novo cliente

      criarNovoCliente() {
        this.router.navigate(["/clientes/novo"])

        }

        //metodo para carregar todos os clientes na inicializacao
      
  ngOnInit(): void {
      this.selecionartodos();
  }
}

