import { url } from 'node:inspector';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { cliente } from './cliente.modelo';
import { MatSnackBar } from '@angular/material/snack-bar';

@Injectable({
  providedIn: 'root'
})
export class ClienteService {

  //Url da API

  url: string = "http://localhost:8080/clientes";

  //constructor

  constructor(private http:HttpClient,
              private snackBar: MatSnackBar,
  ) { }

 //metodo para exibir mensagem

  showMessage(msg: string): void {
    this.snackBar.open(msg, 'X', {
      duration: 3000,
      horizontalPosition: "right",
      verticalPosition: "top"
    })
  }

  // Metodo para selecionar todos os clientes

  selecionartodos():Observable<cliente[]> {
    return this.http.get<cliente[]>(this.url);
  }

  cadastrar(cliente:cliente):Observable<cliente> {
    return this.http.post<cliente>(this.url, cliente);

  }

  lerporcodigo(codigo: number): Observable<cliente>{
    const url = `${this.url}/${codigo}`
    return this.http.get<cliente>(url);

  }

  atualizar(cliente:cliente):Observable<cliente> {
    const url = `${this.url}/${cliente.codigo}`
    return this.http.put<cliente>(url, cliente);
  }

  remover(cod: number):Observable<cliente> {
    const url = `${this.url}/${cod}`;
    return this.http.delete<cliente>(url);
  }

}
