import { cliente } from './../cliente.modelo';
import { ClienteService } from './../cliente.service';
import { Router } from '@angular/router';
import { Component } from '@angular/core';

@Component({
  selector: 'app-cliente-novo',
  standalone: false,
  
  templateUrl: './cliente-novo.component.html',
  styleUrl: './cliente-novo.component.css'
})
export class ClienteNovoComponent {

  cliente: cliente = {
    nome: '',
    cep: '',
    endereco: '',
    numero: '', 
    bairro: '',
    cidade: '',
    estado: '',
    cpf: '',
    datadenascimento: '',
    datadecadastro: '',

  };

  constructor(private router: Router,
    private servico:ClienteService
   ) {}

cancelar() {
this.router.navigate(["/clientes"])
}
  
cadastrar(): void {
 this.servico.cadastrar(this.cliente).subscribe(() => {
    this.servico.showMessage("Cliente criado com sucesso!!!")
    this.router.navigate(['/clientes'])
  })
}
  
}
