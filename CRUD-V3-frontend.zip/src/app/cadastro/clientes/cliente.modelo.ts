export interface cliente {

    codigo? : number;
    nome : String;
    cep : String;
    endereco : String;
    numero : String;
    bairro : String;
    cidade : String;
    estado : String;
    cpf : String;
    datadenascimento : String;
    datadecadastro : String;

}