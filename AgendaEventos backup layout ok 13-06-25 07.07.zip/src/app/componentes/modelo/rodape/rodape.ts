import { Component } from '@angular/core';

@Component({
  selector: 'app-rodape',
  standalone: false,
  templateUrl: './rodape.html',
  styleUrl: './rodape.css'
})
export class Rodape {

}
