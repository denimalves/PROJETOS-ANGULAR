import { AgendaAtualizar } from './componentes/agendamentos/agenda-atualizar/agenda-atualizar';
import { AgendaDeletar } from './componentes/agendamentos/agenda-deletar/agenda-deletar';
import { AgendaNovo } from './componentes/agendamentos/agenda-novo/agenda-novo';
import { AgendaComponent } from './componentes/agendamentos/agenda/agenda';
import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Home } from './home/home';

const routes: Routes = [
 // { path: '', redirectTo: 'agenda', pathMatch: 'full' },
  { path: '', component: Home },
  { path: 'agenda', component: AgendaComponent },
  { path: 'agenda/novo', component: AgendaNovo},
  { path: 'agenda/atualizar/:id', component: AgendaAtualizar },
  { path: 'agenda/deletar/:id', component: AgendaDeletar }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
