import { LOCALE_ID, NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule, registerLocaleData } from '@angular/common';
import { AppRoutingModule } from './app-routing-module';
import { RouterModule, } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { App } from './app';

import { Cabecalho } from './componentes/modelo/cabecalho/cabecalho';
import { Rodape } from './componentes/modelo/rodape/rodape';
import { Navegacao } from './componentes/modelo/navegacao/navegacao';
import { Menu } from './componentes/modelo/menu/menu';
import { AgendaComponent } from './componentes/agendamentos/agenda/agenda';
import { AgendaAtualizar } from './componentes/agendamentos/agenda-atualizar/agenda-atualizar';
import { AgendaDeletar } from './componentes/agendamentos/agenda-deletar/agenda-deletar';
import { AgendaNovo } from './componentes/agendamentos/agenda-novo/agenda-novo';
import { Home } from './home/home';

import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core'; // usa datas JS nativas

import ptBr from '@angular/common/locales/pt';
registerLocaleData(ptBr);

@NgModule({
  declarations: [
    App,
    Cabecalho,
    Rodape,
    Navegacao,
    Menu,
    AgendaAtualizar,
    AgendaDeletar,
    AgendaNovo,
    AgendaComponent,
    Home,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
        CommonModule,
        RouterModule,
        HttpClientModule,
            MatTableModule,
            MatButtonModule,
            MatCardModule,
            MatIconModule,
            MatToolbarModule,
            MatFormFieldModule,
            MatInputModule,
            MatDatepickerModule,
            MatNativeDateModule,
  ],
  providers: [
    provideBrowserGlobalErrorListeners(),
    { provide: LOCALE_ID, useValue: 'pt-BR' }
  ],
  bootstrap: [App]
})
export class AppModule { }
