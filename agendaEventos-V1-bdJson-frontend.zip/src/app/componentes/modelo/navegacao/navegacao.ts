import { Component } from '@angular/core';

@Component({
  selector: 'app-navegacao',
  standalone: false,
  templateUrl: './navegacao.html',
  styleUrl: './navegacao.css'
})
export class Navegacao {

}
