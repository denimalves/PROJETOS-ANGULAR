export interface Agendamento {
  id?: number;
  nome: string;
  data: string;
  horario: string;
  descricao?: string;
}

