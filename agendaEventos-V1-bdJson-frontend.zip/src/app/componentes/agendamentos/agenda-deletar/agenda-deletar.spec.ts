import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgendaDeletar } from './agenda-deletar';

describe('AgendaDeletar', () => {
  let component: AgendaDeletar;
  let fixture: ComponentFixture<AgendaDeletar>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AgendaDeletar]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AgendaDeletar);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
