import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AgendamentoService } from '../servicos/agenda.servico';
import { Agendamento } from '../agendamento.modelo';

@Component({
  standalone: false,
  selector: 'app-agenda-deletar',
  templateUrl: './agenda-deletar.html',
  styleUrls: ['./agenda-deletar.css']
})
export class AgendaDeletar implements OnInit {
  agendamento!: Agendamento;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private servico: AgendamentoService
  ) {}

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.servico.buscarPorId(id).subscribe(res => this.agendamento = res);
  }

  confirmarExclusao() {
    this.servico.deletar(this.agendamento.id!).subscribe(() => {
      this.router.navigate(['/agenda']);
    });
  }
}
