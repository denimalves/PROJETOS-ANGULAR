import { Component, OnInit } from '@angular/core';
import { AgendamentoService } from '../servicos/agenda.servico';
import { Agendamento } from '../agendamento.modelo';
import { Router } from '@angular/router';


@Component({
  standalone: false,
  selector: 'app-agenda',
  templateUrl: './agenda.html',
  styleUrls: ['./agenda.css']
})
export class AgendaComponent implements OnInit {
  agendamentos: Agendamento[] = [];


  // Define as colunas que a tabela irá exibir
  colunas: string[] = ['nome', 'data', 'horario', 'acoes'];

  constructor(private servico: AgendamentoService, private router: Router) {}

  ngOnInit() {
    this.servico.listar().subscribe(res => this.agendamentos = res);
  }
}
