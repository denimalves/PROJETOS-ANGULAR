import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AgendamentoService } from '../servicos/agenda.servico';
import { Agendamento } from '../agendamento.modelo';

@Component({
  standalone: false,
  selector: 'app-agenda-atualizar',
  templateUrl: './agenda-atualizar.html',
  styleUrls: ['./agenda-atualizar.css']
})
export class AgendaAtualizar implements OnInit {
  agendamento: Agendamento = { nome: '', data: '', horario: '', descricao: '' };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private servico: AgendamentoService
  ) {}

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.servico.buscarPorId(id).subscribe(dados => this.agendamento = dados);
  }

  atualizar() {
    this.servico.atualizar(this.agendamento).subscribe(() => {
      this.router.navigate(['/agenda']);
    });
  }
}

