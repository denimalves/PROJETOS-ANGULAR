import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgendaAtualizar } from './agenda-atualizar';

describe('AgendaAtualizar', () => {
  let component: AgendaAtualizar;
  let fixture: ComponentFixture<AgendaAtualizar>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AgendaAtualizar]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AgendaAtualizar);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
