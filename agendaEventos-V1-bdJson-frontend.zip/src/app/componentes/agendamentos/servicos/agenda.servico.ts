import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Agendamento } from '../agendamento.modelo';

@Injectable({ providedIn: 'root' })
export class AgendamentoService {
  private baseUrl = 'http://localhost:3000/agendamentos';

  constructor(private http: HttpClient) {}

  listar(): Observable<Agendamento[]> {
    return this.http.get<Agendamento[]>(this.baseUrl);
  }

  buscarPorId(id: number): Observable<Agendamento> {
    return this.http.get<Agendamento>(`${this.baseUrl}/${id}`);
  }

  criar(agendamento: Agendamento): Observable<Agendamento> {
    return this.http.post<Agendamento>(this.baseUrl, agendamento);
  }

  atualizar(agendamento: Agendamento): Observable<Agendamento> {
    return this.http.put<Agendamento>(`${this.baseUrl}/${agendamento.id}`, agendamento);
  }

  deletar(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
}
