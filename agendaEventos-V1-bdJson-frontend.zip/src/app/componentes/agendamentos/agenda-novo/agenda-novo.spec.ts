import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgendaNovo } from './agenda-novo';

describe('AgendaNovo', () => {
  let component: AgendaNovo;
  let fixture: ComponentFixture<AgendaNovo>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AgendaNovo]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AgendaNovo);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
