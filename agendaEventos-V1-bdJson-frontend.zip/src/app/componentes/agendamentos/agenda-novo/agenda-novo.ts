import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AgendamentoService } from '../servicos/agenda.servico';
import { Agendamento } from '../agendamento.modelo';

@Component({
  standalone: false,
  selector: 'app-agenda-novo',
  templateUrl: './agenda-novo.html',
  styleUrls: ['./agenda-novo.css']
})
export class AgendaNovo {
  agendamento: Agendamento = { nome: '', data: '', horario: '', descricao: '' };

  constructor(private servico: AgendamentoService, private router: Router) {}

  salvar() {
    this.servico.criar(this.agendamento).subscribe(() => {
      this.router.navigate(['/agenda']);
    });
  }
}

