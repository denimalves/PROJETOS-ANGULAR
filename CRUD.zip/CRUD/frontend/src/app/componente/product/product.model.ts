export interface Product {
    id?: number
    nome: string
    preco: number
}