import { ProductService } from './../../../componente/product/product.service';
import { Component, OnInit } from '@angular/core';
import { Product } from '../../../componente/product/product.model';
import { ActivatedRoute, Route, Router } from '@angular/router';

@Component({
  selector: 'app-product-delete',
  standalone: false,
  
  templateUrl: './product-delete.component.html',
  styleUrl: './product-delete.component.css'
})
export class ProductDeleteComponent implements OnInit {

  product: Product;

  constructor(
    private productService: ProductService,
    private router: Router,
    private route: ActivatedRoute

  ) {

  }
  
  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id')
    this.productService.readById(id).subscribe(product => {
      this.product = product;
    })
  }
 
  deleteProduct(): void {
    this.productService.delete(this.product.id).subscribe(() => {
      this.productService.showMessage('Produto exxcluido com sucesso')
      this.router.navigate(['/products']);
    }
  )
  }

  cancel(): void {
    this.router.navigate(['/products'])
  }
}

