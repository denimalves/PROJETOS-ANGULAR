import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { Cabecalho } from './componentes/modelo/cabecalho/cabecalho';
import { Rodape } from './componentes/modelo/rodape/rodape';
import { Navegacao } from './componentes/modelo/navegacao/navegacao';
import { Menu } from './componentes/modelo/menu/menu';

@NgModule({
  declarations: [
    App,
    Cabecalho,
    Rodape,
    Navegacao,
    Menu,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [
    provideBrowserGlobalErrorListeners()
  ],
  bootstrap: [App]
})
export class AppModule { }
